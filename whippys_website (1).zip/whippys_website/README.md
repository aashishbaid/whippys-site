# Whippy's — Kilpauk website concept

A responsive, interactive single-page website concept made as a front-end prototype. Open `index.html` in a modern browser.

## Included
- Responsive layout for phones, tablets and desktops
- Animated hero and scrolling dessert ticker
- Searchable menu with category filters
- Favourite/save buttons for menu items
- Kilpauk address and embedded map search
- Links to public ordering and discovery pages
- Clear separation between the Kilpauk Swiggy listing and Teynampet Zomato/District listings

## Before publishing as the official business website
This is an independent concept, not an owner-approved or deployed official website. Please obtain approval from the business and verify:
- Kilpauk outlet phone number, email and WhatsApp
- Official Instagram account ownership
- Opening hours, dine-in/takeaway facilities and delivery coverage
- Live menu, prices, product descriptions and availability
- Permission to use all business photos, logos and brand assets
- Correct branch-specific Google Business Profile / Maps pin

The Kilpauk address and FSSAI licence shown in the concept were taken from the public Swiggy listing. No Kilpauk-specific phone number was confirmed. Zomato and District links currently point to the Teynampet listing and are explicitly labelled as a separate outlet.

## Public pages referenced
- Kilpauk Swiggy: https://www.swiggy.com/city/chennai/whippys-kilpauk-rest1456110
- Whippy's Instagram handle: https://www.instagram.com/whippys.in/
- Teynampet Zomato listing: https://www.zomato.com/chennai/whippys-teynampet
- Teynampet District listing: https://www.district.in/dining/chennai/whippys-teynampet

The visual photos are hotlinked from publicly accessible Whippy's images on Swiggy/Zomato listing pages. Replace with owner-approved, optimized local image assets before commercial deployment.
